import { Component } from "@angular/core";

@Component({
      selector: "customer-header",
      templateUrl: "./customer-header.component.html",
      styleUrls: ["./customer-header.component.scss"]
})
export class CustomerHeaderComponent {
      constructor() {}
}
