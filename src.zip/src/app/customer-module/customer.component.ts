import { Component} from "@angular/core";


@Component({
      selector: "customer",
      templateUrl:'./customer.component.html' 
})
export class CustomerComponent {
  constructor() {
  }
}
