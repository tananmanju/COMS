import { Component } from '@angular/core';
//import { CustomersModule } from "./customer-module/customer.module";

@Component({
  selector: 'app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

}
