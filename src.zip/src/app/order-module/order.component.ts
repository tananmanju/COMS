import {Component} from "@angular/core";


@Component({
	selector: 'order-component',
	template:'<h1>Hello from the order</h1>'
})

export class orderComponent{
    constructor(){

    }
}


