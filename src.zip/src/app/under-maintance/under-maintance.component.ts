import { Component } from "@angular/core";

@Component({
    selector: "under-maintance",
    templateUrl: "./under-maintance.component.html",
    styleUrls: ["./under-maintance.component.scss"]
})
export class UnderMaintanceComponent {
  constructor() {}
}
